SCCP.EXE : MTP - SCCP and TCAP decoder.

September 05, 2012.

0.  CONTENTS
------------

0.  CONTENTS
1.  INTRODUCTION
2.  TOOLBAR BUTTON SETTINGS
3.  MENU SETTINGS
4.  DECODING OPTIONS
5.  DECODING UNFORMATTED OCTETS
6.  DECODING UNIX Trace Log
7.  DECODING PROTOCOL ANALYZER TRACE LOGS
8.  DECODING CPP/CELLO AND MGW TRACE LOGS
9.  EXPORTING TRACE DATA TO WIRESHARK and ETHEREAL
10. ASN1BER TTFILE DECODER
11. SCCP READER APPLICATION
12. TEST SYSTEM Trace
13. CONFIGURATION FILES
14. SCRIPT FILES
15. COMMAND LINE
16. README FILE
17. QUESTIONS/PROBLEMS


1.  INTRODUCTION
----------------

THIS APPLICATION IS A DECODER AND SHOULD NOT BE USED AS REPLACEMENT OF PROTOCOL ANALYZER.

See file 'Sccp_Decoder_Configuration.htm' in README sub-directory.

The decoder is not complete. Testing has been very limited.

An audit function has been added to show any unread octets.
The audit result is only output when such condition exists.


2.  TOOLBAR BUTTON SETTINGS
---------------------------

Select the required 'Toolbar Buttons' for various decoder functions and settings.

  'Folder'  - Open a trace log for decoding
  'Floppy'  - Save decoded trace in a file
  '-> File' - Not is use

  'ANSI' - Select MTP and SCCP for 'ANSI'  (24 bit DPC)
  'ITU'  - Select MTP and SCCP for 'ITU'   (14 bit DPC)
  'MPT'  - Select MTP and SCCP for 'China' (24 bit DPC)
  'TTC'  - Select MTP and SCCP for 'Japan' (16 bit DPC)

  'SI=4 is IUP' - MTP SI=4 is decoded as UK IUP instead of TUP

  'SCCP BSS'   - SCCP connection oriented message DT1 data defaults to BSSAP
  'SCCP RANAP' - SCCP connection oriented message DT1 data defaults to RANAP

  'CDMA BSS' - BSS messages are decoded as CDMA BSS instead of GSM BSS

  'TCAP ASN1' - ASN.1 BER Interpretation of ITU TCAP and TCAP users MAP, INAP and CAP
  'ASN1 PER'  - ASN.1 PER Interpretation of RANAP
  'DE-CODE'   - Decode protocol data for some of the 'ASN.1 Interpreted' parameters

  'ETH MTP'   - Not is use
  'ETH SCTP'  - Not in use
  'RUN e'     - Start 'Wireshark Protocol Analyzer' with capture file.
                See section '9.  EXPORTING TRACE DATA TO WIRESHARK' below for details.

  'READ SCCP' - Start 'SccpReader.exe' with current decoded result as input.


Default startup settings of these toolbar buttons and various settings can be changed
by editing the 'SCCPAPP.ICF' file in SCCP\ sub-directory. Restart the decoder after
making changes in 'SCCPAPP.ICF'.


3.  MENU SETTINGS
-----------------

A 'right-click' on 'Result Output' window will display the following menu.

     |-- 'Copy'       - Copy selected text to clipboard
     |
     |-- 'Paste'      - Decode text in clipboard. If clipboard contains one or more files copied
     |                  from Windows Explorer then contents of these files are decoded.
     |
     |-- 'Select All' - Select all the text in SCCP output window
     |
     |-- 'Clear'      - Clear all the text in output window
     |
     |-- 'Find'       - Search for a string in output window
     |
     |-- 'Find Next'  - Repeat the previous search for a string in output window


Decoder mode can be changed by 'Left click' or 'Right click' on status bar.

Select the required 'Menu' options for various decoder functions and settings.

Menu -
     |   
     |---File
     |    |
     |    |-- 'Open'     - Open a trace log for decoding
     |    |
     |    |-- 'Save As'  - Save decoded trace in a file
     |    |
     |    |-- 'Exit'     - Close SCCP decoder
     |   
     |---Edit 
     |    |
     |    |-- 'Copy'       - Copy selected text to clipboard
     |    |
     |    |-- 'Paste'      - Decode text in clipboard. If clipboard contains one or more files copied
     |    |                  from Windows Explorer then contents of these files are decoded.
     |    |
     |    |-- 'Select All' - Select all the text in SCCP output window
     |    |
     |    |-- 'Clear'      - Clear all the text in output window
     |    |
     |    |-- 'Find'       - Search for a string in output window
     |    |
     |    |-- 'Find Next'  - Repeat the previous search for a string in output window
     |    |
     |    --- 'View Decoder Output in Text Editor'
     |                       View decoder output in 'Notepad.exe'
     |
     |---Decode
     |    |
     |    |-- 'Clipboard'  - Decode data in clipboard
     |    |
     |    |-- 'Bearer Capability...' - Decode GSM or ISDN BC hex octets
     |    |
     |    |-- 'ETHERIC...' - Decode ETHERIC hex octets
     |    |
     |    |-- 'TTFILE...' - Decode ASN.1 BER encoded TTFILE
     |    |
     |    |                  See section '10.  ASN1BER TTFILE DECODER' below for details.
     |    |
     |    |-- 'Unformatted Octets...' - Decode unformatted octets
     |    |
     |    |
     |    |-- 'Create Wireshark/Ethereal pcap File' - Octets from trace data are saved in Wireshark
     |    |                                 capture file in .cap format
     |    |
     |    |                                 If this option is selected then toolbar buttons
     |    |                                 'TCAP ASN1', 'ASN1 PER' and 'DE-CODE' are disabled
     |    |
     |    |                                 See section '9.  EXPORTING TRACE DATA TO WIRESHARK' below for
     |    |                                 details.
     |    |
     |    |-- 'Wireshark/Ethereal pcap Link Layer...' 
     |    |     |
     |    |     |---'MTP3'     - Trace octets are stored in Wireshark capture
     |    |     |                file with MTP3 routing label
     |    |     |
     |    |     |---'Ethernet' - Trace octets are stored in Wireshark/Ethereal capture
     |    |                      file with ETHERNET-IP-SCTP-M3UA headers
     |    |
     |    |-- 'Save Wireshark/Ethereal Pcap File As...
     |    |                                    Save Wireshark/Ethereal exported data in user specified file.
     |    |
     |    |-- 'BSC Trace Log' - Select this option if TEST SYSTEM trace is made on BSC node for BSSAP
     |    |                     decoding. This is required for correct signal direction.
     |    |
     |    |                     De-select if trace is made on any other type of node.
     |    |
     |    |-- 'Decode Input With Script'
     |    |                     Decode clipboard or file input using the script specified by user.
     |    |
     |    |                     See sample script 'DecodeSHPM3Opcode.sb' stored in 'Script\DecodeInput\'
     |    |                     sub-directroy. Sample input file for this script is 'SHPM3_VAR_01.log'
     |    |                     and is also stored in same sub-directory.
     |    |
     |    |-- 'Decoder Mode...'
     |          |
     |          |---'Default' - Select this mode for decoding following type 
     |          |               of trace logs
     |          |   
     |          |                    - TEST SYSTEM trace log
     |          |                    - UPMTI
     |          |                    - BIMTI
     |          |                    - C7MTI
     |          |                    - MTPMI
     |          |                    - Tektronix Hex Print
     |          |   
     |          |---'ss7trace.log' - Decode 'ss7trace.log'
     |          |                    Only messages between MTPL2 and MTPL3 are decoded
     |          |
     |          |---'Decode Wireshark/Ethereal Packet Capture File'
     |          |                    Decode Wireshark/Ethereal Packet Capture File.
     |          |
     |          |                        Ethernet - IPv4 - SCTP - M3UA - Payload
     |          |                        Ethernet - IPv4 - SCTP - H.248 (GCP)
     |          |                        Ethernet - IPv4 - SCTP - BICC
     |          |                        MTP3
     |          |
     |          |---'Protocol Analyzer Trace Log' - Decode trace result of various protocol
     |          |                                   Analyzer trace logs. 
     |          |
     |          |                                   See section '7.  DECODING PROTOCOL ANALYZER TRACE LOGS'
     |          |
     |          |---'CELLO and GPRS Trace Log' - Decode trace results from CELLO and GPRS
     |          |                                (Not fully implemented yet).
     |          |                                See section '8.  DECODING CPP/CELLO AND MGW TRACE LOGS'
     |          |
     |          |---'OIP CB Trace Log' - Decode 'PRINT CB' trace log that only contains OIP communication
     |                                           buffer data'
     |                                           All 'PRINT CB' printouts in this trace will be assumed
     |                                           to contain OIP data. With this decoder mode it is not required to
     |                                           setup 'SCCPAPP.ICF' file with :SIGNAL_SETUP or :PRINT_CB_SETUP for
     |                                           ON IN, ON OU, ON IA or ON VAR trace that was used to print OIP
     |                                           buffer with 'PRINT CB'. However if the same trace log also contains
     |                                           'PRINT CB' printouts that conatin some other protocol data then use
     |                                           the default decoder mode and setup the OIP signal/IA trace in
     |                                           'SCCPAPP.ICF' for correct decoding.
     |
     |---Tools
     |    |
     |    |---- 'Verify Single Module ASN.1 Links' - 
     |    |
     |    |---- 'Verify TCAP User ASN.1 Module Links' - 
     |    |
     |    |---- 'Create TCAP User ASN.1 Module for Components' - 
     |    |        See file 'SccpDecoderManualDecoding.txt' for details on how to create ASN.1 files
     |    |        for TCAP user protocols MAP, INAP and CAP for the 'invoke/ARGUMENT' and 
     |    |        'returnResult/RESULT' and then use ASN1BER.EXE to decode hex octet string that
     |    |        contain only the 'invoke/ARGUMENT' or 'returnResult/RESULT'.
     |    |
     |    |---- 'Create ASN.1 Module Identifiers List' -
     |    |
     |    |---- 'Split ASN.1 TCAP User Module' - 
     |    |
     |    |---- 'List of ASN.1 BER Encoded Tags' - 
     |    |
     |    |---- 'List Un-Referenced ASN.1 Definitions' - 
     |    |
     |    |---- 'Raw ASN.1 BER Decoding of Binary File' - 
     |    |
     |    |---- 'Convert Unix File to MS-DOS FOrmat' - 
     |    | 
     |    |---- 'Convert Wireshark/Ethereal Pcap file to Hex'
     |    | 
     |    |---- 'Change SYRIP Signal Sequence' - 
     |    |                Compared to TEST SYSTEM trace, the sequence of signals
     |    |                in SYRIP is reversed for signals of type C7EMITMSUI/S/E.
     |    |                Also in SYRIP the last received signal is printed at the
     |    |                top while in TEST SYSTEM trace it is at the end.
     |    |                Use this menu option to change the signal sequence in SYRIP
     |    |                printout and save it to an intermediate file for decoding.
     |    |
     |    |---- 'Change LOG CB Printout Sequence' - 
     |    |                Compared to 'PRINT CB' output, the sequence of trace
     |    |                printout is reversed for 'LOG CB' output.
     |    |                Use this option to change the printout sequence
     |    |                before decoding.
     |    |
     |    |---- 'Apply Configuration File Settings' - 
     |    |
     |    |                Use this menu option to apply configuration file settings.
     |    |                Default directory for these files is 'SCCP\' application sub-directory
     |    |                and file format is based on SCCPAPP.ICF file found in this directory.
     |    |
     |    |                Prepare the new configuration file by adding the required settings. See
     |    |                'SCCPAPP.ICF' for more details and avaibale options.
     |    |
     |    |---  'Run Script ...' - 
     |
     |                     Run Script files for decoding various trace logs by writing new scripts.
     |
     |---Options
     |    |
     |    |---- 'Printout Format...
     |    |     |
     |    |     |---'Default'
     |    |     |                 Native printout format
     |    |     |
     |    |     |---'Format 1'
     |    |                       New format with printout aligned left (very limited testing performed).
     |    |
     |    |---- 'Create 'SEND SIGNAL' Data Word String'
     |    |                  TEST SYSTEM trace octets output as SEND SIGNAL data words in 'H'vvww, H'xxyy' format.
     |    |
     |    |-----'Octets per Data Word'
     |    |                        |
     |    |                        |---'One Octet'
     |    |                        |          One octet per data word.
     |    |                        |
     |    |                        |---'Two Octets'
     |    |                                   Two octets per data word.
     |    |
     |    |-----'Set Default Version for TCAP User Protocols
     |    |           Set default version for TCAP Users MAP, INAP and CAP/CAMEL.
     |    |
     |    |-----'Decode MTP3 Maintenance and Networking Messages'
     |    |
     |    |---- 'GCPH RP Signal Setup'
     |    |           |
     |    |           |--- 'CN2.0'
     |    |           |
     |    |           |--- 'CN3.0 and CN4.0'
     |    |           |
     |    |           |--- 'CN5'
     |    |           |
     |    |           |--- As Setup in SCCPAPP.ICF configuration file'
     |    |
     |    |---- 'Display Last Decoding Duration'
     |    |          Display the time taken to decode last trace input.
     |    |
     |    |---- 'Save Result To Temporary File'
     |    |          Decoding result will be saved to temporary file 'TEMP\OUTPUT.TXT.
     |    |          Decoding result will not be displayed in main decoder window.
     |    |
     |    |---- 'Suppress Result File Output'
     |    |          Use this option while decoding large trace files and exporting data to Wireshark pcap file.
     |    |          This option is only available when menu option 'Decode - Create Wireshark pcap File' is active.
     |    |
     |    |---- 'Save Settings Now'
     |    |          Current settings are saved at the time of this menu option selection.
     |    |
     |    |---- 'Save Settings On Exit'
     |               If this option is checked then following settings are saved at exit.
     |
     |                  - Directory name of last file opened for decoding
     |                  - Toolbar button settings
     |                  - Decoder mode
     |
     |---Help 
          |
          |----'Read Me' - This text is diplayed in output window.
          |
          |----'Sccp Quick Guide'
          |                Display 'SCCP_GUIDE.HLP' file stored in READM\ sub-directory.
          |
          |----'Download Latest Version'
          |                Download latest version of Sccp decoder.
          |
          |----'Record 'Saved Hours' in EKB
          |                If use of 'Sccp Decoder' has saved you time then record that
          |                in EKB at 'Sccp Decoder' KO web page.
          |
          |----'About'   - Display 'About' information.


Default startup settings of various menu options and other settings can be changed
by editing the 'SCCPAPP.ICF' file in SCCP\ sub-directory. Restart the decoder after
making changes in 'SCCPAPP.ICF'.


4.  DECODING OPTIONS
--------------------

It can decode the following.

   - ITU-T and ANSI MTP network and maintenance messages.

   - All SCCP messages for ITU-T and ANSI SCCP including segmented SCCP messages.

   - Partial decoding of UK IUP for both TEST SYSTEM and C7MTI trace.

   - Partial decoding of ISUP for ITU Q763 and ANSI 5.3 for UPMTI and TEST SYSTEM trace.

   - Partial decoding of BICC for BIMTI and TEST SYSTEM trace.
     Decoding of APP/APM paremeters and IPBCP.
     Very limited testing performed.

   - ASN.1 decoding of ITU-T TCAP Q.773 and ANSI TCAP.

   - Labeling of TCAP OpCodes for MAP, INAP and CAP.

   - Labeling of IS41 TCAP OpCodes and TAGs. Partial decoding of IS41 Tag data.

   - Partial decoding of GSM and CDMA BSSAP (BSSMAP and DTAP).

   - Partial decoding of GSM BSSAP+ (Gs Interface).

   - Decoding of Hex printout (Tektronix K1205, K1297 and others). Decoding starts from 
     octet number 0 or 3. This octet is decoded as MTP SIO.

      Example :

         +----+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
         |HEX |0 |1 |2 |3 |4 |5 |6 |7 |8 |9 |A |B |C |D |E |F |
         +----+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+--+
         |0   |b6|b8|38|83|64|80|34|40|01|28|01|03|02|02|06|04|
         |10  |43|64|00|fe|04|04|43|d2|00|fe|0f|1e|00|1c|57|05|
         |20  |08|00|32|f4|10|00|01|00|28|17|0d|05|24|71|03|30|
         |30  |18|81|05|f4|00|10|08|f9|21|81|00|  |  |  |  |  |

      To output hex octets in Tektronix analyzer, check the 'Hex Frame/Raw Octets' option
      while saving decoded trace to disk.

   - Decoding of signals in SYRIP:EVENT=event; (RESTART DATA) printout.

     Decoding of signals in SYRIP printout requires changing the sequence of signals
     using menu 'Tools - Change SYRIP Signal Sequence' option. A new log file is
     created containing signals from SYRIP log file with first signal at the top
     and LAST SIGNALS at the end of the file. This new file has 'Signals.log' appended
     to the input SYRIP log file name. Use this new file as decoder input

   - Decoding GSM or ISUP 'Bearer Capability' raw octets.
     Select menu option 'Decode-Bearer Capability'.

   - Decoding of 'ss7trace.log' for messages between MTPL2 and MTPL3.
     Select menu option 'Decode - Decoder Mode ... - ss7trace.log'

         Input from clipboard or file is now decoded for ss7trace.log data.

         Sixth octet in this trace is decoded as MTP SIO.

   - Partial decoding of CDMA BSSAP (no testing performed).

   - Decoding of RANAP-PDU by labeling only the message type.

   - Decoding of 'directTransfer' in RANAP (Iu-CS) NAS-PDU messages.

   - Partial decoding of SIGTRAN M3UA 'Protocol Data' payload for TEST SYSTEM trace.

   - Partial decoding of R11 ABIS TEST SYSTEM trace.

   - Partial decoding of DSS1 Q.931 unformatted octets.

   - Partial decoding of BTAP (A-ter) Interface messages.

   - Decoding of RTCAP (RTCfA) 'Real Time Charging for All' protocol

   - ASN.1 decoding of GCP with interpretation of GCP ASN.1 module and tag labeling.
     Decoder is setup for CN3.0 GCPH RP signals by default.
     To decode CN2.0 RP signals, make sure the 'Decode - GCP CN3.0' menu option
     is un-checked.
     Check the 'Decode - GCP CN3.0' menu option to decode CN3.0 RP signals.

   - Decoding of TTFILE is now possible by using 'ASN1BER.exe'

   - Decoding of raw unformatted hex octets.
     Select menu option 'Decode - Unformatted Octets'.

        First octet can be either
                                      - MTP2, BSN
                                      - MTP2, BSN - G.703 ANNEX-A
                                      - MTP3, SIO
                                      - SCCP, Message Type
                                      - BSSAP, Protocol Discriminator
                                      - BSSAP+, Message Type
                                      - TCAP, First Tag
                                      - GCP, First Tag
                                      - M3UA, Common Message Header
                                      - SCTP, Source Port Number
                                      - BICC, CIC
                                      - Ethernet, Dest MAC Address
                                      - RANAP-PDU
                                      - DSS1, Protocol Discriminator
                                      - IUA, Version
                                      - SUA, Revison
                                      - ASCII Encoded Text
                                      - LAPD, Address Field


   - ASN.1 interpretation of ITU-TCAP according to ASN.1 module specified in Q.773.

   - ASN.1 interpretation of ITU-TCAP user protocols, MAP, INAP and CAP
     according to user specified ASN.1 modules. For setup details see file
     'Sccp_Decoder_Configuration.htm' in README sub-directory.

   - ASN.1 interpretation of ITU-TCAP user protocols dialogue 'user-information'
     according to specified ASN.1 module. For setup details see file
     'Sccp_Decoder_Configuration.htm' in README sub-directory.

   - ASN.1 interpretation of MAP Version 3 ExtensionContainer according to
     specified ASN.1 module. For setup details see file
     'Sccp_Decoder_Configuration.htm' in README sub-directory.

   - ASN.1 interpretation of Charging Interrogation Protocol CIP to SDP.

   - ASN.1 interpretation of ANSI-TCAP according to ANSI TCAP R4, 1992.
     For setup details see file 'Sccp_Decoder_Configuration.htm' in README
     sub-directory.

   - ASN.1 interpretation of IS41 according to any specified ASN.1 module.
     For setup details see file 'Sccp_Decoder_Configuration.htm' in README
     sub-directory.

   - ASN.1 PER interpretation of RANAP according ASN.1 module in 3GPP TS 25413.700.
     For setup details see file 'Sccp_Decoder_Configuration.htm' in README
     sub-directory.

   - ASN.1 PER interpretation of following

          - NBAP according to ASN.1 module in 3GPP TS 25433-680.
          - RNSAP according to ASN.1 module in 3GPP TS 25423-680.
          - RRC according to ASN.1 module in 3GPP TS 25331-760.

   - LAPD decoding according to ITU Q.921.


     NOTE : VERY LIMITED TESTING PERFORMED.


     Use menu option 'Decode - TTFILE', copy Raw-Hex octets to clipboard and select
     the following

       1. Input - Clipboad
       2. File Format - Hex Octets
       3. Check 'ASN.1 PER'
       4. Select NBAP/RNSAP/RRC ASN.1 module, use 'ASN.1 Module...' button

     For setup details see file 'Sccp_Decoder_Configuration.htm' in README
     sub-directory.


5.  DECODING UNFORMATTED OCTETS
-------------------------------

To decode unformatted octets, from menu select 'Decode - Unformatted Octets'
In the dialog box input can be from a file, clipboard or by typing in octets.

First octet maybe any of the following

     - MTP2, BSN
     - MTP2, BSN - G.703 ANNEX-A
     - MTP3, SIO
     - SCCP, Message Type
     - BSSAP, Protocol Discriminator
     - BSSAP+, Message Type
     - TCAP, First Tag
     - GCP, First Tag
     - M3UA, Common Message Header
     - SCTP, Source Port Number
     - BICC, CIC
     - Ethernet, Dest MAC Address
     - RANAP-PDU
     - DSS1, Protocol Discriminator
     - IUA, Version
     - SUA, Revison
     - ASCII Encoded Text
     - LAPD, Address Field

Example: 

         - Following hex octets contains BSSMAP 'Assignment Failure' message

             00 06 03 04 01 0A 15 09


         - Octet below contain TTC ISUP IAM Message.
 
             15 12 34 45 67 07 17 00 01 00 60 01 0A 00 02 0A 08 03 10 32
             54 76 80 68 49 0A 07 03 13 21 43 05 00 10 FD 04 81 33 00 00
             F1 08 00 FB 05 FE 03 00 90 30 1D 03 80 90 A2 00

Unformatted GCP hex octets can also be decoded in 'Decode - TTFILE' option
by selecting the GCP ASN.1 module.

Unformatted RANAP hex octets can also be decoded in 'Decode - TTFILE' option
by selecting the RANAP ASN.1 module.

Various RRC PDUs hex octets can also be decoded in 'Decode - TTFILE' option
by selecting the RRC PDU ASN.1 module.

Decoding of TTC-Japan MTP is implemented only for decoding TTC ISUP.
SCCP decoding for TTC is not yet implemented and currently is based on ITU SCCP.


6.  DECODING UNIX Trace Log
---------------------------

    Trace log files from Unix and other similar operating systems only
    have a LF (linefeed) character at the end of each line. SCCP decoder can not
    read such files. These can be converted to MS-DOS text file format
    by using Windows WordPad application by using the 'File - SaveAs'
    menu option and selecting 'Save as type :' 'Text Document - MS-DOS Format'.

    This MS-DOS text format file can now be used for decoding with SCCP decoder.

    Alternatively use SCCP decoder menu option 'Tools - Convert Unix File to MS-DOS Format'


7.  DECODING PROTOCOL ANALYZER TRACE LOGS
-----------------------------------------

  - Decoding of protocol analyzer trace logs of following six types can be performed 
    from the menu select 

          'Decode - Decoder Mode ... - Protocol Analyzer Trace log' 

    Status bar now shows decoder mode changed to 'Protocol Analyzer Trace Log'
    In this mode, input can be from clipboard or from a file.

    For Type 1 and Type 2 trace logs below, only the TCAP messages are decoded.
    While for Type 3, 4, 5 and 6 decoding is started from MTP SIO.

    These trace logs may have one of the five following formats.

    Type 1. Raw Octets from following type of trace log are extracted that may cause some error
            as numeric fields in trace log have their octets combined into one string.

       Decoding starts from 'TCAP Message Type' signified by string 
       '******************** TCAP Layer ********************' in the trace log.

       A section of sample Trace Log is given below

            ******************** TCAP Layer ********************
            
            
               Package Type Section
            01100010 : 62 : Package Type        :    TCAP Begin
            01100010 : 62 : TCAP Message Length :    98
            
               Transaction ID Section
            
            
            01001000 : 48 : Transaction ID      :    Originating TX ID
            00000100 : 04 : Trans ID Length     :    4


    Type 2. Raw Octets from following type of trace log are extracted that may cause some error
            as numeric fields in trace log have their octets combined into one string.
            (This trace log format is of SPECTRA protocol analyzer).

       Decoding starts from 'TCAP Message Type' signified by string 
       'TCAP message,' in the trace log.

       A section of sample Trace Log is given below

            � octet037  TCAP message, transaction portion..................................�
            � 01100010 � Package type...... � BEG   Begin, constructor, Appl. wide         �
            � 00111110 � Message length.... � 62                                           �
            � 01001000 � Transaction ID tag � Originating transaction ID tag               �
            � 00000001 � Xaction ID length. � 1                                            �
            � 00000001 � Originating ID.... � 1                                            �
            � octet042  TCAP message portion: UMTS.........................................�
            � 01101100 � Portion Tag....... � Component portion tag                        �
            � 00111001 � Component Len..... � 57                                           �
            � octet044  Component transaction message type: UMTS-MAP.......................�


    Type 3. Raw Octets from following type of trace log are extracted without any error and
            decoding starts from 'MTP SIO' (Service Information Octet) signified by string
            'Service Indicator =' in the trace log.
            (This trace log format is of Agilent protocol analyzer).

       A section of sample Trace Log is given below

                1       | 1|0000110 | BIB = 1,  BSN =   6                                                     
                2       | 1|0011110 | FIB = 1,  FSN =  30                                                     
                3       | 00|111111 | Length Indicator : MSU, LI =  63 octets                                 
                4       | 1000|0011 | Service Indicator = SCCP, SSF = National Network                        


    Type 4. Raw Octets from following type of trace log are extracted without any error and
            decoding starts from 'MTP SIO' (Service Information Octet) signified by string
            '*** Start of MTP(MTP) ***' in the trace log.
            (This trace log format is of unknown protocol analyzer).

       A section of sample Trace Log is given below

            *** Start of MTP(MTP) ***
                              MSU
            0003 10000011 83
                 ----0011    Service Indicator                        0011 - SCCP
                 --00----    Network Priority                         00 - priority 0
                 10------    Network Indicator                        10 - National Network
            0004 00101000 20 Destination Point Code                   (2-32-32)
            0005 00111010 20
            0006 00000010 02
            0007 00000001 02 Origination Point Code                   2-32-2
            0008 00111010 20
            0009 00000010 02
            0010 01110101 75 Signaling Link Selection                 117


    Type 5. Raw Octets from following type of trace log may be extracted with errors and
            decoding starts from 'MTP SIO' (Service Information Octet) signified by string
            'Octet004  Service information octet' in the trace log.
            (This trace log format is of GeoProbe protocol analyzer).

       A section of sample Trace Log is given below

                --------------------------------------------------------------------------------
                 Octet004  Service information octet
                --------------------------------------------------------------------------------
                 ....0011  Service indicator      (3) SCCP   Signalling Connection Control Part
                 ..01....  Message priority       1
                 10......  Network indicator      (2) N  National network
                --------------------------------------------------------------------------------
                 Octet005  Routing label
                --------------------------------------------------------------------------------
                 ........  DPC: Net-Clstr-Mbr     211-255-255 eastalias
                 ........  OPC: Net-Clstr-Mbr     001-044-130
                 00010001  SLS                    17
                --------------------------------------------------------------------------------
                 Octet012  Message type
                --------------------------------------------------------------------------------
                 00001001  Message type           (9) UDT   Unitdata
                --------------------------------------------------------------------------------

    Type 6. Raw Octets from following type of trace log are read without errors.
            Decoding starts from 'MTP SIO' (Service Information Octet). That is 
            octet 4 in the raw hex octet string
            (This trace log format is of unknown protocol analyzer).

       A section of sample Trace Log is given below

            -------------------------------------------------------------------------------------
            Time   Ms  Link    Length  DPC OPC SLS CIC Message type    Application
            20:23:18   312 AkpnA0_6    109 6125    4168    06  -   UDT  BEGIN, Op=Send Auth Info
            20:23:18   464 Rbtfr0_1    148 4186    4112    09  -   UDT  END, Op=Send Auth Info
            -------------------------------------------------------------------------------------
            82 F1 3F 03 ED 17 12 64 09 81 03 10 1B 0D 12 06 00 71 04 13 26 56 00 10 84 87 03 0B 12
                       MTP - ITU Q.703 
            1-------   BIB - Backward Indicator Bit    1
            -0000010   BSN - Backward Sequence Number  2   
            1-------   FIB - Forward Indicator Bit 1   
            -1110001   FSN - Forward Sequence Number   113 
            00------   Spare   0   -
            --111111   LI - Length Indicator   63  
                       SIO 
            00------   NI - Network Indicator  0   International network
            --00----   Spare   0   -
            ----0011   SI - Service Indicator  3   SCCP - Signalling Connection Control Part


8.  DECODING CPP/CELLO AND MGW TRACE LOGS
-----------------------------------------

    Decoding of CPP/CELLO and MGw trace logs for following.

        Scc_ansiServer_proc   (ANSI)
        Scc_ituServer_proc    (ETSI)
        Scc_chinaServer_proc  (MPT/China)
        Scc_ttcServer_proc    (TTC/Japan)
        Ans_aal2ap_proc       (AAL2)
        SccSctpHost_proc      (SCTP/M3UA)
        gcp_buffer            (GCP)
        stcMbaMtp3biClientC[  (GCP)

    These trace logs may be in Unix text file format. See section '6.  DECODING UNIX Trace Log'

    Select menu option 'Decode - Decoder Mode... - CELLO and GPRS Trace Log'

    This trace data can be exported to Ethereal/Wireshark.
    See section '9.  EXPORTING TRACE DATA TO WIRESHARK and ETHEREAL' below.


9.  EXPORTING TRACE DATA TO WIRESHARK and ETHEREAL
--------------------------------------------------

    This option is available if 'Wireshark' is installed on local machine.
    See http://www.wireshark.org for Wireshark.

    To use 'Ethereal' instead, edit file 'SCCPAPP.ICF' and point the configuration setup
    string ':ETH_APP_PATH' to 'Ethereal.exe' file instead of default 'Wireshark.exe'.

    'Wireshark capture (.cap)' file can be created by activating this function.
    From menu select 'Decode - Create Wireshark pcap file'. When this option is
    ativated then 'TCAP ASN1', 'ASN1 PER' and 'DE-CODE' toolbar buttons are
    disabled. From menu select 'Decode - Create Wireshark pcap file' again to
    enable these toolbar buttons.

    Depending on the 'Wireshark Link Layer' setting, input trace log is converted
    to pcap file with either 'MTP3' or 'Ethernet' headers.

    If menu setting is for MTP3 and file also contains SCTP-M3UA trace then only
    'Payload' data is saved in pcap file and other M3UA network and maintenance
    messages are discarded.

    If menu setting is for Ethernet and file also contains MTP3 trace then only
    Service Indicator 3 to 15 data is copied to pcap file and SS7 network and 
    maintenance messages are discarded.

    Default values for NI, OPC, DPC (and CIC) are used for trace data that do 
    not have MTP3 routing label or M3UA common message header in message data.

    If link layer is set to MTP3 and trace logs contains M3UA data then OPC and
    DPC values copied from M3UA message to MTP3 routing label will only have 14 
    or 16 significant bits. This will happen if M3UA trace contains ANSI MTP 
    signalling point data while MTP setting on toolbar is for ITU or TTC. 
    Select the ANSI MTP from toolbar for getting the correct DPC and OPC values 
    copied from M3UA to MTP3 routing label.

    Wireshark 'mtp3.standard:' perefrence is set to 'ANSI', 'ITU', 'Chinese ITU' or 'Japan'
    according to the toolbar button 'ANSI', 'ITU', 'MPT' or 'TTC'.

    Wireshark capture file is stored in application sub-directory TEMP\ as 'sccp.cap'.

    See file 'SCCP_Decoder_Configuration.htm' in README\ sub-directory for more details.


10.  ASN1BER TTFILE DECODER
---------------------------

   - This is a separate application for decoding ASN.1 BER encoded TTFILE.

   - Application 'ASN1BER.exe' is stored in ASN1BER\ sub-directory. It can also be used
     for following Binary and Hex TTFILE format conversions.

   - Conversion of IOFAT:FILE=file,HEX; printout to BINARY format.

   - Conversion of Hex octet file to BINARY format.

   - Conversion of BINARY file to Hex format.

   - Conversion of APG IOFAT HEX printout to BINARY format.


11. SCCP READER APPLICATION
---------------------------

   - This is a separate application that takes SCCP decoder result and displays the
     messages between various signalling points in graphical format for easier viewing.

     Application SccpReader.exe is stored in SccpReader\ sub-directory.

     Click 'READ SCCP' toolbar button to start 'SccpReader.exe' with current decoded
     result, in SCCP decoder display window, as input to 'SccpReader.exe'.


12. TEST SYSTEM Trace
---------------------

    For APZ real time clock timestamp (same as CACLP; printout value), use following

      ON IN/OU DO: PRINT VAR JOB 8;     ! CCLOCK !
                   PRINT VAR JOB 80;    ! CDECSECCNT !
                   PRINT VAR JOB 249;   ! CCENTSECCNT !
                   P SWD,;

    For alternative timestamp, use PRINT MS as the first measure.

      ON IN DO: PRINT MS, P SWD,;
      ON OU DO: PRINT MS, P SWD,;

    GSM BSSAP decoding in signals

      ON OU SCCOC SCDATAIND;
      ON IN SCCOC SCDATAREQ;

    And also GSM BSSAP in signals

      ON IN/OU block RNICOMIND;
      ON IN/OU block RNICOMRRSZ;
      ON IN/OU block RNICOMRHSZ;
      ON IN/OU block RNOCOMREQ;

      ON IN/OU block BSSAPICOMIND;
      ON IN/OU block BSSAPICOMIND1I;
      ON IN/OU block BSSAPICOMRRSZ;
      ON IN/OU block BSSAPICOMRRSZI;
      ON IN/OU block BSSAPOCOMREQ1;
      ON IN/OU block BSSAPOCOMREQ1I;

    SCCP Connection Oriented messages in signal.

      ON IN/OU block C7TAKECOM5 C7TAKECOM3I C7TAKECOM2S C7TAKECOM3E;

   BSSAP decoding of signals in BSC
   This requires the 'BSC Trace Log' option to be checked under 'Decode' menu.
   Uncheck this option for decoding BSSAP trace from MSC.

      ON IN/OU block RACOSNDBSSMAP1C;
      ON IN/OU block RACOTAKEBSSMAPC;
      ON IN/OU block RACOSENDDTAP1C;
      ON IN/OU block RACOTAKEDTAPC;

   CDMA BSSAP decoding of signals in MSC.
   Note : check the 'CDMA BSS' button in toolbar.

      ON IN/OU block BSAPOCOMREQ;

   Decoding of 'directTransfer' RANAP (Iu-CS) NAS-PDU messages for signals
   This trace can also be used for MAP signalling on 3G MSC Servers.

     ON IN C7DR2 ALIRECEIVEDMSG ALIRECEIVEDMSGI ALIRECEIVEDMSGS ALIRECEIVEDMSGE;
     ON OU C7DR2 ALITRANSMSG ALITRANSMSGI ALITRANSMSGS ALITRANSMSGE;

   To capture all messages on ATM AAL5, use the following trace. This includes
   MTP, SCCP, MAP, INAP, CAP, GCP and RANAP messages.

     ON OU SAALH RP;
     ON OU SAALH ALIRECEIVEDMSG ALIRECEIVEDMSGI ALIRECEIVEDMSGS ALIRECEIVEDMSGE;

   GCP Decoding in signals

     ON IN GCPH GCRPROUTEMSU GCRPROUTEMSUI GCRPROUTEMSUS GCRPROUTEMSUE;
     ON OU GCPH RP;
     OFF OU GCPH H'10 H'12;

     Also, GCP in signals

     ON IN GCPH GCRPROUTEMSU1 GCRPROUTEMSUI1 GCRPROUTEMSUS1 GCRPROUTEMSUE1;

   SIGTRAN Decoding in signals

     ! R10 and R11, CN3 and CN4 ;
     ON IN SCTP RPSCTPDARRVINDI RPSCTPDARRVINDS;
     ON OU SCTP RP;

     ! R12, CN5 ;
     ON IN SCTP RPSCTPDRVINDI2 RPSCTPDRVINDS2 RPSCTPDRVINDE2;
     ON OU SCTP RP;

     On VM based APZ 212 40 and 212 50, on R12 and later, RP signals do not 
     contain 'Protocol Data' for SCTP and SAALH RPs due to new feature called 
     'BULKDATA SIGNALS ON RPB-E'.

     Other tracing may still be used for capturing the protocol data in this case.

       ON IN C7DR2 ROUTEMSU ROUTEMSUI ROUTEMSUS ROUTEMSUE;
       ON OU C7DR2 TAKEMSU TAKEMSUI TAKEMSUS TAKEMSUE;

     SCCP Messages in :

       ON OU C7CO ROUTEMSU ROUTEMSUI ROUTEMSUS ROUTEMSUE;

       ON OU C7CL ROUTEMSU ROUTEMSUI ROUTEMSUS ROUTEMSUE;
       ON IN C7SRMH TAKEMSU TAKEMSUI TAKEMSUS TAKEMSUE;

     ISUP Messages in :

       ON OU UPLTD ROUTEMSU ROUTEMSUI ROUTEMSUS ROUTEMSUE;
       ON IN UPLTD TAKEMSU TAKEMSUI TAKEMSUS TAKEMSUE;

     Test block 'M' :

     In test plant enviornment, use test block 'M'. This can be down loaded
     from this page by 'Andreas Ejdne' at http://unix.epa.ericsson.se/~epaejdn/M

     Click on links 'Work' - 'C7 Monitor'

     Use new command MTPMI to capture protocol data.

     Test block 'M' also makes it possible to capture protocol data for co-located
     nodes like MSC/VLR/HLR, HLR/AUC, HLR/FNR and SSF/SCF. Use parameter LOCAL in
     in command MTPMI to capture such messages.


   ISUP Decoding in signals

     ON IN UPLTD ROUTEMSG ROUTEMSGI ROUTEMSGS ROUTEMSGE;
     ON OU UPLTD TAKEMSG TAKEMSGI TAKEMSGS TAKEMSGE;

     ON IN UPLTD AROUTEMSG AROUTEMSGI AROUTEMSGS AROUTEMSGE;
     ON OU UPLTD ATAKEMSG ATAKEMSGI ATAKEMSGS ATAKEMSGE;

   R11 ABIS Decoding in signals

     ON OUT RCLCCH RNRECABISMSGC;
     ON OUT RCLCCH RNRECABISMSGI RNRECABISMSGS RNRECABISMSGE;
     ON IN RCLCCH RNSENDABISMSGC;
     ON IN RCLCCH RNSENDABISMSGI RNSENDABISMSGS RNSENDABISMSGE;
     ON IN RCLCCH RNSNDABISMSGC10;

   R9 and R10 ABIS Decoding in signals

     ON OUT RCLCCH RCRECABISMSGC;
     ON OUT RCLCCH RCRECABISMSGI RCRECABISMSGS RCRECABISMSGE;
     ON IN RCLCCH RCSENDABISMSGC;
     ON IN RCLCCH RCSENDABISMSGI RCSENDABISMSGS RCSENDABISMSGE;
     ON IN RCLCCH RCSNDABISMSGC10;

   R13 now supports printing of CB (Communication Buffer) data with 'PRINT CB'
   This printout can be decoded by using ':SIGNAL_SETUP' and ':PRINT_CB_SETUP' in
   file 'SCCPAPP.ICF'. Also see sample printout in file 'Sccp_History.txt' in README\
   sub-directory. Signals STCTRANSIND, STCTRANSREQ and G7TAKECOMSGCB are already setup
   for 'PRINT CB' decoding. More signals can be setup as required.

   Decoding of 'LOG CB' is also supported. The printout sequence of 'LOG CB' is
   opposite to that of 'PRINT CB' in that the latest trace printout is at
   top of the trace log and the earliest trace at the end of the file. To decode such
   trace use the menu option 'Tools - Change LOG CB Printout Sequence' to change this
   sequence and decode the modified file.

      MTP3 tracing:

         ! ANSI ;
         ON IN DO: P IA, P SWD, PRINT CB IN DR7, PRINT CB IN DR8,;
         ON OU DO: P IA, P SWD, PRINT CB IN DR8, PRINT CB IN DR9,;

         ON IN S7DR S7ROUTECBMSG;
         ON OU S7DR S7TAKECBMSG;

         ! ITU, ETSI ;
         ON IN DO: P IA, P SWD, PRINT CB IN DR10,;
         ON OU DO: P IA, P SWD, PRINT CB IN DR10,;

         ON IN C7DR2 G7ROUTECBMSG;
         ON OU C7DR2 G7TAKECBMSG;

      GCP tracing:

         ON IN DO: P IA, P SWD, IF DR3=0 THEN, P CB IN DR4, ELSE, PRINT CB IN DR5, FI,;
         ON OU DO: P IA, P SWD, IF DR7=0 THEN, P CB IN DR8, ELSE, PRINT CB IN DR9, FI,;

         ON IN GCPH STCTRANSIND;
         ON OU GCPH STCTRANSREQ;

      M2PA tracing:

         ON IN DO: P IA,P SWD, IF DR2=0 THEN, P CB IN DR3, ELSE, P CB IN DR4, FI,;
         ON OU DO: P IA,P SWD, P CB IN DR2,;

         ON IN M2PA M2PATRANSCBMSG;
         ON OU M2PA M2PARECCBMSG;

      M3UA tracing:

         ON IN DO: P IA,P SWD, IF DR6=1 THEN, P CB IN DR7, ELSE, PRINT CB IN DR8, FI,;
         ON OU DO: P IA,P SWD, IF DR7=1 THEN, P CB IN DR8, ELSE, PRINT CB IN DR9, FI,;

         ON OU M3UADR SCTPSENDCBREQ;
         ON IN M3UADR SCTPDARRVCBIND1;

      GCP tracing:

         ON IN DO: P IA,P SWD, IF DR6=1 THEN, P CB IN DR7, ELSE, PRINT CB IN DR8, FI,;
         ON OU DO: P IA,P SWD, IF DR7=1 THEN, P CB IN DR8, ELSE, PRINT CB IN DR9, FI,;

         ON OU STCIH SCTPSENDCBREQ;
         ON IN STCIH SCTPDARRVCBIND1;

      SIP tracing:

         ON IN DO:P SWD, PRINT CB IN DR1,;
         ON IN ACSIP SIPDECODE;

         LASIP:BLOCK=TRSIP;

         ! FOR THE 'ON IA' TRACE BELOW THE TRSIP SUID SHOULD BE '7PLE/CAAZA107 3026/MY1D R1A21' ;
         ! H'2B9C IS ENTRY ADDRESS FOR COMBINED BACKWARD SIGNAL 'SIPENCODEACK' ;

         ON IA DO: P IA, P DR0-DR10, PRINT CB IN DR4,;
         ON IA TRSIP H'2B9C; 

         ! FOR THE 'ON IA' TRACE BELOW THE TRSIP SUID SHOULD BE '7PME/CAAZA 107 3231/MY2BU R1A35' ;
         ! H'36EC IS ENTRY ADDRESS FOR COMBINED BACKWARD SIGNAL 'SIPENCODEACK' ;

         ON IA DO: P IA, P DR0-DR10, PRINT CB IN DR4,;
         ON IA TRSIP H'36EC; 

         SIP and SIP-I decoding can be performed via Wireshark. Before decoding the above trace, from menu
         select 'Decode - Create Wireshark pcpap file' and then selecet the following from menu
         'Decode - Wireshark pcap Link Layer ... - Ethernet'. Once the decoding is complted then
         decoder should show how many SIP messages have been exported in Wireshark pcap format.
         Click the 'Run e' toolbar button to start Wireshark and open the ecxported pcap file directly.

      OIP tracing:

         ON IN DO:P SWD, PRINT CB IN DR4,;
         ON IN TRARE MSG;

         ON OU DO: P IA, P SWD, PRINT CB IN DR0,;
         ON OU MTA MSENDFWDMSG;

         ON IN DO: P IA, P SWD, PRINT CB IN DR0,;
         ON IN MTA MRECBWDMSG;

      PRA/DSS1/Q.931 tracing:

         ON OU DO: P IA, P SWD, PRINT CB IN DR2,;
         ON OU MHPRAG IUADATAREQ;

         ON IN DO: P SWD, PRINT CB IN DR3,;
         ON IN  MHPRAG IUADATAIND1;


NOTE : ALL TRACES LISTED HERE ARE ONLY FOR TEST PLANT USE.

Log TEST SYSTEM trace for ITU or ANSI MTP with

 ! FOR ITU-T MTP ;

   TEST SYSTEM;
   TERM;
   CLEAR;
   TMSIZE=32768;
   TESYS=0;

   TELMP;
   ! SET THE VALUES ARE REQUIRED ;
   ! TELMI:LOAD=80,TI=10;

   PLLDP;

   ! CHANGE THE NUMBER OF TIMES THE SIGNALS ARE PRINTED ;
   ! REPLACE 2000 BELOW WITH THE REQUIRED VALUE ;
   ON IN DO: FOR 2000 TIMES, P SWD,;
   ON OU DO: FOR 2000 TIMES, P SWD,;


   ON IN C7DR2 C7DISCRMSU C7DISCRMSUI C7DISCRMSUS C7DISCRMSUE;
   ON OU C7DR2 C7EMITMSU C7EMITMSUI C7EMITMSUS C7EMITMSUE;

 ! FOR ANSI MTP ;

   ON IN S7DR S7RECMESS S7RECMESSI S7RECMESSS S7RECMESSE;
   ON OU S7DR S7SENDMESS S7SENDMESSI S7SENDMESSS S7SENDMESSE;

Other possible traces allow conditional trace on specified ST pointer(s).
Use trace like ...

   TEST SYSTEM;
   TERM;
   CLEAR;
   TMSIZE=32768;

   ! FOR TEST PLANT USE ONLY ;
   ! FOR TEST PLANT USE ONLY ;
   ! FOR TEST PLANT USE ONLY ;
   ! FOR TEST PLANT USE ONLY ;
   ! FOR TEST PLANT USE ONLY ;

   ! Get ST pointer(s) from C7LDP:LS=ls;
   ! ON IN DO: [IF PR0= st-pointer1 [, st-pointer2, ...],] P SWD,;

   ON IN C7ST2C C7EMITMSU C7EMITMSUI C7EMITMSUS C7EMITMSUE;
   ON IN C7ST2C C7RPMSU C7RPMSUI C7RPMSUS C7RPMSUE;

   ON IN C7ST2 C7EMITMSU C7EMITMSUI C7EMITMSUS C7EMITMSUE;
   ON IN C7ST2 C7RPMSU C7RPMSUI C7RPMSUS C7RPMSUE;

   ON IN C7STH C7EMITMSU C7EMITMSUI C7EMITMSUS C7EMITMSUE;
   ON IN C7STH HS7RPMSG HS7RPMSGI HS7RPMSGS HS7RPMSGE;

   ON IN C7GSTH C7EMITMSU C7EMITMSUI C7EMITMSUS C7EMITMSUE;
   ON IN C7GSTH G7RPMSG G7RPMSGI G7RPMSGS G7RPMSGE;

   ON IN C7STAH C7EMITMSU C7EMITMSUI C7EMITMSUS C7EMITMSUE;
   ON IN C7STAH C7RETMSU C7RETMSUI C7RETMSUS C7RETMSUE;

   ON IN S7ST S7SENDMESS S7SENDMESSI S7SENDMESSS S7SENDMESSE;
   ON IN S7ST C7RPMSU C7RPMSUI C7RPMSUS C7RPMSUE;

   ON IN S7STG S7SENDMESS S7SENDMESSI S7SENDMESSS S7SENDMESSE;
   ON IN S7STG C7RPMSU C7RPMSUI C7RPMSUS C7RPMSUE;

More signal definitions can be added in file SCCPAPP.ICF, see comments
and existing signal setup to add more signals in file SCCPAPP.ICF .


Decoding of following Plex signals is implemented with script files as listed.
All these scipts are stored under sub-directory 'Script\Signals\'

For decoding of any other required signal, see file 'Sccp_Script_Files.htm'
stored in 'README\' sub-directory and the existing script files listed below.

   FORWARDPLMNBC          Script\Signals\DecodeFORWARDPLMNBC.sb
   ORTECONG               Script\Signals\DecodeORTECONG.sb
   G7DIALSEIZEREQI        Script\Signals\DecodeG7DIALSEIZEREQI.sb
   SHINVOKE               Script\Signals\DecodeSHINVOKE.sb
   G7UDTINDE              Script\Signals\DecodeG7UDTINDE.sb
   G7UDTREQE              Script\Signals\DecodeG7UDTREQE.sb
   C7ROUTEORIGCL4         Script\Signals\DecodeC7ROUTEORIGCL4.sb
   SHLELENCOUNT           Script\Signals\DecodeSHLELENCOUNT.sb
   SHLELREPORT            Script\Signals\DecodeSHLELREPORT.sb
   SHARMLEL               Script\Signals\DecodeSHARMLEL.sb
   SHDISARMLEL            Script\Signals\DecodeSHDISARMLEL.sb
   SHDPENCOUNT1           Script\Signals\DecodeSHDPENCOUNT1.sb
   SHDPQUEUE1             Script\Signals\DecodeSHDPQUEUE1.sb
   G7BEGININD             Script\Signals\DecodeG7BEGININD.sb
   C7TRANSLATEGT2         Script\Signals\DecodeC7TRANSLATEGT2.sb
   BPREANA                Script\Signals\DecodeBPREANA.sb
   FETCHINDATA            Script\Signals\DecodeFETCHINDATA.sb 
   C7TAKESCMMESS2         Script\Signals\DecodeC7TAKESCMMESS2.sb 
   C7TRANSLATEGT4R        Script\Signals\DecodeC7TRANSLATEGT4R.sb 
   SENDCCCDATA1           Script\Signals\DecodeSENDCCCDATA1.sb
   SENDCCCDATA            Script\Signals\DecodeSENDCCCDATA1.sb
   HREQISDNBCAN           Script\Signals\DecodeHREQISDNBCAN.sb
   HREQISDNBCANR          Script\Signals\DecodeHREQISDNBCANR.sb
   SHOIPPARAREAD          Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHOIPPARAREADRE        Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHOIPPARAREADRS        Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHOIPPARAREADRF        Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHOIPPARASTOREE        Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHOIPPARASTORES        Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHOIPOCTREAD           Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   APCDATACBIND           Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   APCDATACBREQ           Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGBUF                 Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGBUFSUB              Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGRETHELDEND          Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGQUEINHOLD           Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGRECEIVED            Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGRETURN              Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSG                    Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGRETINHOLD           Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSGINHOLD              Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHMSGREC               Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHMSGRECR              Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHMSGRECF              Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHMSGTOKENREQ          Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHMSGTOKENREQR         Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHMSGTOKENREQF         Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHPREPOIPMSG           Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHPREPOIPMSGR          Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHSENDMSG1             Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   SHPREPOIPMSGF          Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSENDFWDMSG            Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MSENDMSGJ              Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MRECBWDMSG             Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   MRECMSGJ               Script\Signals\LMC\LMCSHAFDecodeOIP.sb
   WRITELOG, WRITELOGEND  Script\Signals\LMC\LMCSHAFDecodeCHVIEW.sb
   WRITELOGEND            Script\Signals\LMC\LMCSHAFDecodeCHVIEW1.sb


13. CONFIGURATION FILES
-----------------------

  - For SCCP decoder configuration see html file 'Sccp_Decoder_Configuration.htm' 
    in README sub-directory.


  - Decoder has a configuration file for various default settings for MTP, SCCP SSN
    and TCAP SSN assignments. This file is stored under application directory.

         SCCP\SCCPAPP.ICF


14. SCRIPT FILES
----------------

    See 'Sccp_Script_Files.htm' in README\ sub-directory for details.

    To edit SCCP script files, use file 'SccpScriptEditor.xls' stored in README\ sub-directory.


15. COMMAND LINE
----------------

    Sccp decoder supports following command line parameters

      SCCPyymmdd.exe  -i <inputFile> [-o <outputFile>] [-c <configFile>]

           -i <inputFile>   - Input trace log file

           -o <outputFile>  - Output file to save decoded result

           -c <configFile>  - Config file having same format as 'SCCPAPP.ICF'
                              Settings in this file are applied before decoding
                              input trace log file.

    Sccp decoder GUI is not visible if all the specified files are found.
    Decoded trace is saved to specified file and decoder session is ended.
    If any of the specified files are not found then command line is discarded
    and decoder is started with GUI. If output file is not specified then
    decoder GUI is started and decoded result is displayed in output window.

    File names having space characters must be specified with enclosing double quote.

     Examples :

       C:\Tools\Decoders\Sccp>SCCP061010.exe -i "C:\Trace File.log" -o "C:\Trace File.sccp.txt" -c "C:\Config File.icf"

       C:\Tools\Decoders\Sccp>SCCP061010.exe -i TraceFile.log -o TraceFile.sccp.txt -c \SCCP\SccpAnsiConfig.icf

       C:\Tools\Decoders\Sccp>SCCP061010.exe -i TraceFile.log

       C:\Tools\Decoders\Sccp>SCCP061010.exe -i TraceFile.log -o TraceFile.sccp.txt


16. README FILE
---------------

This text is stored in SCCP\README\Sccp_Readme_Screen.txt file in application 
sub-directory. Contents of this file are presented to the user at startup of 
SCCP decoder and also via 'Help - Read Me' menu option.


17. QUESTIONS/PROBLEMS
----------------------

If you have questions/problems: 

 - Download the current copy of decoder from

       http://users.eei.ericsson.se/~lmishd

 - Read this file and also see 'Sccp_Decoder_Configuration.htm' file in README 
   sub-directory.

 - If that would not solve your problem, contact LMISHD.

   Please provide 
    
      1. 'Last Modified Date' of SCCP decoder.
      2. Trace log that is showing decoding problems.
      3. Description of error message(s) displayed.


/End of file.
