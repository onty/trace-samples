
ASN1BER.EXE : ASN.1 BER and PER Interpreter

Version  : 1.0
Revision : 15

Last Updated on : November 10, 2011.


0.   CONTENTS
-------------

1.  Application
2.  User Interface
3.  Decoding Multiple Files
4.  Adding new ASN.1 Modules
5.  Limitations
6.  Script Files
7.  Questions/Problems


1.  APPLICATION
---------------

 ASN.1 BER and PER decoding and interpretation of following according to the 
 specified ASN.1 module

   - ASN.1 BER encoded TTFILE.

   - ASN.1 BER encoded file.

   - ASN.1 PER encoded file with PER-BASIC-ALIGNED or PER-BASIC-UNALIGNED variant.


2.  USER INTERFACE
------------------

 - Right-click on 'Result Output' window will display the following menu.

     |-- 'Copy'       - Copy selected text to clipboard
     |
     |-- 'Paste'      - Decode text in clipboard. If clipboard contains one or more files copied
     |                  from Windows Explorer then contents of these files are decoded.
     |
     |-- 'Select All' - Select all the text in output window
     |
     |-- 'Clear'      - Clear all the text in output window
     |
     |-- 'Find'       - Search for a string in 'Result Output' window
     |
     |-- 'Find Next'  - Repeat the previous search for a string in 'Result Output' window


 - Select the format of input file/clipboard data from toolbar buttons

    IOFAT HEX,  for 'IOFAT:FILE=file,HEX;' printout in a file or clipboard.
    BIN,        for 'Binary' format file.
    HEX,        for 'Hex octets' in a file or in clipboard.
    IOFAT APG,  for 'APG IOFAT Hex' octets in a file or in clipboard.
                This output is created by 'bin2hfat.exe'.

       For 'Hex Octet' format, each toll ticket must have a blank line at the end
       to mark the start of next toll ticket. If such blank lines are not included
       then this TTFILE in 'Hex Octet' format may be first converted to 'Binary'
       format from menu option 'Hex2Bin Bin2Hex Conversion'. This 'Binary' file can
       now be decoded.

 - For Binary input file, select the block length as unknown from toolbar by clicking 
   the '?' button.

 - For result output, click any of the four toolbar buttons as required

   LABEL ASN1,  for displaying interpreted input data with selected ASN.1 Module 
                in drop-down list.

   TAG DATA,    for displaying decoded tag data of interpreted ASN.1.

   READ OCTET,  for displaying raw hex octets read from file or clipboard.

   RAW ASN.1,   for displaying Raw ASN.1 decoded result.

 - For TTFILE application click the toolbar button 'TT'.

 - ASN1 PER,    for interpreting ASN.1 PER encoded input (Hex or Binary)

 - If Drop-Down-List in toolbar does not show the required ASN.1 Module name then
   select ASN.1 file from menu 'Options - Change ASN1 Module Directy' and 
   select a new ASN.1 Module. This will update the Drop-Down-List in toolbar with all 
   the ASN.1 modules found in that directory.

 - To start decoding, select the input file from menu 'File - Open'  to decode a file
   or 'Edit - Paste' to decode data in clipboard.


3.  DECODING MULTIPLE FILES
---------------------------

 To decode multiple files use menu option 'File - Decode Multiple Files'
 In the dialog box, select one of the files and then edit the file name by
 adding required wildcard characters. Press OK to start decoding.

Alternatively...

 To decode multiple files use command prompt/MS-DOS prompt to copy all files 
 into a single file. 

   Example:

    - To decode multiple IOFAT:HEX TTFILE logs like

       TTFILE01.LOG
       TTFILE02.LOG
       TTFILE03.LOG
       TTFILE04.LOG and so on, use command line

         >COPY TTFILE*.LOG ALLTTFILES.LOG

       This will copy all the files into a single file called ALLTTFILE.LOG

       File ALLTTFILE.LOG can now be decoded using menu 'File - Open'.


    - To decode multiple binary format TTFILE logs like

       TTFILE.200503301200583388
       TTFILE.200503301205583389
       TTFILE.200503301210583390
       TTFILE.200503301215583391
       TTFILE.200503301220583392 and so on, use command line

         >COPY TTFILE.2005033012*.* /B ALLTTFILES.BIN /B

       This will copy all the files into a single file called ALLTTFILES.BIN

       File ALLTTFILES.BIN can now be decoded using menu 'File - Open'.


4.  ADDING NEW ASN.1 MODULES
----------------------------

 - New ASN.1 Modules can be added and verified by using menu option 
   'Tools - Verfiy Single Module ASN.1 Links'.


5.  LIMITATIONS
---------------

 - ASN1BER.EXE is based on minimal functionality to decode and interpret only TTFILE.

 - Raw ASN.1 decoding of data block with more than 4096 bytes is not supported.

 - Binary format files for AUTOMATIC TAGS ASN.1 modules can be decoded for upto 2GB size.

 - Decoding of Tag-Data for Binary files with AUTOMATIC TAGS ASN.1 modules not supported.

This text is stored in \README\Asn1ber_Readme.txt file in application 
sub-directory. Contents of this file are presented to the user at startup of 
ASN1BER decoder and also via menu option 'Help - Read Me'.


6.  Script Files
----------------

    TTFILE fields can be decoded using script file.

    Add parameter name under ':DECODE' setting in '<filename>.PARA.txt'
    in ASN1 sub directory and specify the script file name for decoding
    this TTFILE field.


7.  QUESTIONS/PROBLEMS
----------------------

If you have questions/problems:

 - Read this file.

 - If that would not solve your problem, contact LMISHD.

   Please provide
    
      1. 'Last Modified Date' of ASN1BER decoder.
      2. Trace log that is showing decoding problems.
      3. Description of error message(s) displayed or decoding faults.


/End of file.

