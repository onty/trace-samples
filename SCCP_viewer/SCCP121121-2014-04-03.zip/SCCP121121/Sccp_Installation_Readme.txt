
SCCP Decoder Installation
-------------------------

November 21, 2012.

Copy the entire directory structure to a new folder on hard disk and 
rename file 'Sccp_Installation.bat.txt' by removing its '.txt' extension.  

Double click the renamed file 'Sccp_Installation.bat' in Windows Explorer to
complete the installation process.

/end of file.
  